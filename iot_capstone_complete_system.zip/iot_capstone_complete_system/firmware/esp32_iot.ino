/*
  Capstone: Complete IoT System
  ESP32 -> MQTT -> Web Dashboard

  Libraries:
    WiFi.h
    PubSubClient
    DHT sensor library
    ArduinoJson

  Keep credentials in secrets.h, not in this file.
*/

#include <WiFi.h>
#include <PubSubClient.h>
#include <DHT.h>
#include <ArduinoJson.h>
#include "secrets.h"

#define DEVICE_ID "device01"
#define DHT_PIN 4
#define DHT_TYPE DHT22
#define LED_PIN 2

const unsigned long PUBLISH_INTERVAL_MS = 10000;

DHT dht(DHT_PIN, DHT_TYPE);
WiFiClient wifiClient;
PubSubClient mqtt(wifiClient);

unsigned long lastPublish = 0;

String telemetryTopic() {
  return String("capstone/") + DEVICE_ID + "/telemetry";
}

String statusTopic() {
  return String("capstone/") + DEVICE_ID + "/status";
}

void connectWiFi() {
  if (WiFi.status() == WL_CONNECTED) return;

  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  Serial.print("Connecting to Wi-Fi");
  unsigned long started = millis();

  while (WiFi.status() != WL_CONNECTED && millis() - started < 15000) {
    delay(500);
    Serial.print(".");
  }

  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("\nWi-Fi connected.");
    Serial.print("IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\nWi-Fi connection timed out; will retry.");
  }
}

bool connectMQTT() {
  if (mqtt.connected()) return true;
  if (WiFi.status() != WL_CONNECTED) return false;

  Serial.println("Connecting to MQTT...");

  String willPayload = "{\"device\":\"" + String(DEVICE_ID) +
                       "\",\"online\":false}";

  bool ok = mqtt.connect(
    DEVICE_ID,
    MQTT_USERNAME,
    MQTT_PASSWORD,
    statusTopic().c_str(),
    1,
    true,
    willPayload.c_str()
  );

  if (ok) {
    Serial.println("MQTT connected.");
    String onlinePayload = "{\"device\":\"" + String(DEVICE_ID) +
                           "\",\"online\":true}";
    mqtt.publish(statusTopic().c_str(), onlinePayload.c_str(), true);
    digitalWrite(LED_PIN, HIGH);
  } else {
    Serial.print("MQTT failed, state=");
    Serial.println(mqtt.state());
    digitalWrite(LED_PIN, LOW);
  }

  return ok;
}

void publishTelemetry() {
  float temperature = dht.readTemperature();
  float humidity = dht.readHumidity();

  if (isnan(temperature) || isnan(humidity)) {
    Serial.println("Sensor read failed.");
    return;
  }

  // Demo battery value. Replace with an ADC-based measurement in hardware.
  int batteryPct = 87;

  StaticJsonDocument<256> doc;
  doc["device"] = DEVICE_ID;
  doc["temperature_c"] = temperature;
  doc["humidity_pct"] = humidity;
  doc["battery_pct"] = batteryPct;
  doc["uptime_s"] = millis() / 1000;

  char payload[256];
  serializeJson(doc, payload);

  if (mqtt.publish(telemetryTopic().c_str(), payload)) {
    Serial.print("Published: ");
    Serial.println(payload);
  } else {
    Serial.println("Publish failed.");
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(LED_PIN, OUTPUT);
  digitalWrite(LED_PIN, LOW);

  dht.begin();
  mqtt.setServer(MQTT_HOST, MQTT_PORT);

  connectWiFi();
  connectMQTT();
}

void loop() {
  connectWiFi();

  if (!mqtt.connected()) {
    connectMQTT();
  }

  mqtt.loop();

  if (mqtt.connected() && millis() - lastPublish >= PUBLISH_INTERVAL_MS) {
    lastPublish = millis();
    publishTelemetry();
  }

  delay(20);
}
