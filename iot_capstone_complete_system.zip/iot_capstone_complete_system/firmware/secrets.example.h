#pragma once

// Copy this file to secrets.h and replace the placeholders.
// DO NOT commit secrets.h to Git.

#define WIFI_SSID "YOUR_WIFI_NAME"
#define WIFI_PASSWORD "YOUR_WIFI_PASSWORD"

#define MQTT_HOST "YOUR_MQTT_BROKER"
#define MQTT_PORT 1883
#define MQTT_USERNAME "YOUR_MQTT_USERNAME"
#define MQTT_PASSWORD "YOUR_MQTT_PASSWORD"
